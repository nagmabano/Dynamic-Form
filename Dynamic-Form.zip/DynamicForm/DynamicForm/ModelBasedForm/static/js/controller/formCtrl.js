/**
 *  author:
 */

app.controller('formCtrl', function($log,$scope,$timeout,formService) {

	$scope.formJSON = {};
	$scope.formData = {};
	$scope.formResponse = {response:'',status:''};

	$scope.model = {
			//  Text-based elements
			'textinput': {element: 'input', type: 'text', className:'form-control'},
			'date': {element: 'input', type: 'date', className:'form-control'},
			'datetime': {element: 'input', type: 'datetime', className:'form-control'},
			'datetime-local': {element: 'input', type: 'datetime-local', className:'form-control'},
			'email': {element: 'input', type: 'email', className:'form-control'},
			'month': {element: 'input', type: 'month', className:'form-control'},
			'number': {element: 'input', type: 'number', className:'form-control'},
			'password': {element: 'input', type: 'password', className:'form-control'},
			'search': {element: 'input', type: 'search', className:'form-control'},
			'tel': {element: 'input', type: 'tel', className:'form-control'},
			'textarea': {element: 'textarea',type:'textarea', className:'form-control'},
			'time': {element: 'input', type: 'time', className:'form-control'},
			'url': {element: 'input', type: 'url', className:'form-control'},
			'week': {element: 'input', type: 'week', className:'form-control'},
			//  Specialized editables
			'checkbox': {element: 'input', type: 'checkbox', className:'checkbox',repeat:true},
			'color': {element: 'input', type: 'color', className:'form-control'},
			'file': {element: 'input', type: 'file', className:'form-control'},
			'range': {element: 'input', type: 'range', className:'form-control'},
			'select': {element: 'select', className:'form-control'},
			//  Pseudo-non-editables (containers)
			'checklist': {element: 'div', className:'form-control'},
			'fieldset': {element: 'fieldset', className:'form-control'},
			'radio': {element: 'input', type:'radio', className:'radio',repeat:true},
			//  Non-editables (mostly buttons)
			'button': {element: 'button', type: 'button', className:'form-control'},
			'hidden': {element: 'input', type: 'hidden', className:'form-control'},
			'image': {element: 'input', type: 'image', className:'form-control'},
			'legend': {element: 'legend', className:'form-control'},
			'reset': {element: 'button', type: 'reset', className:'form-control'},
			'submit': {element: 'button', type: 'submit', className:'form-control'}
	};



	$scope.getForm = function(){
		formService.getDynamicFormJSON().then(function(value) {
			$scope.formJSON = value.data.data;
		}, function(reason) {
			$log.error(reason);
			$scope.formJSON = {};
		});
	}
	
	$scope.submitForm = function(){
		formService.postDynamicFormJSON($scope.formData).then(function(value){
			$log.info(value.data);
			$scope.formResponse.response = true;
			$scope.formResponse.status = 'submitted';
			$timeout(function() {
				$scope.formResponse.response = '';
				$scope.formResponse.status = '';
			}, 3000)
		},function(reason){
			$log.error(reason);
			$scope.formResponse.response = false;
			$scope.formResponse.status = 'failed';
			$timeout(function() {
				$scope.formResponse.response = '';
				$scope.formResponse.status = '';
			}, 3000)
		});
		$scope.formJSON = {};
		$scope.formData = {};
	}

});