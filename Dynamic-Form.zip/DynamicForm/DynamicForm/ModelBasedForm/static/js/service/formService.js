/**
 *  author:
 */

app.service('formService', function($http,$log,$q) {
	
	this.getDynamicFormJSON = function(){
		var def = $q.defer();
		$http.get('https://randomform.herokuapp.com').then(function(value) {
			def.resolve(value);
		}, function(reason) {
			def.reject(reason);
		});
		return def.promise;
	}
	
	
	
	this.postDynamicFormJSON = function(formObj){
		var def = $q.defer();
		$http({
			method: "POST",
		    url: "https://randomform.herokuapp.com/submit",
		    data: formObj
		}).then(function(value) {
			def.resolve(value);
		}, function(reason) {
			def.reject(reason);
		});
		return def.promise; 
	}
	
});