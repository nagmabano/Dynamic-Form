/**
 *  author:
 */

var app = angular.module('myapp', []);